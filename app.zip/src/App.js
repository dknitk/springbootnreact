import React from 'react';
import './App.css';
import Home from './Home';
import { useEffect , useState} from 'react';
import { BrowserRouter as Router, Route,  Routes } from 'react-router-dom';
import GroupList from './GroupList';
import GroupEdit from './GroupEdit';


// function App() {

//   const [groups, setGroups] = useState([]);
//   const [loading, setLoading] = useState(false);

//   useEffect( () =>{
//     setLoading(true);
//     fetch('api/groups')
//     .then(response => response.json())
//     .then(data => {
//       setGroups(data);
//       setLoading(false);
//     })
//   }, []);

//   if(loading){
//     return <p>Loading......</p>
//   }

//   return (
//     <div className="App">
//       <header className="App-header">
//         <h2>Hello, How are you?</h2>
//         {groups.map(group =>
//           <div key={group.id}>
//             {group.name}
//           </div>
//           )}
//       </header>
//     </div>
//   );
// };

const App = () =>{

  return(
    <Router>
       <Routes>
            <Route exact path="/" element={<Home/>} /> 
            <Route path= '/groups' exact={true} element={<GroupList/>} />
            <Route path='/groups/:id' element={<GroupEdit/>} />
          </Routes>
    </Router>
  );
};

export default App;
