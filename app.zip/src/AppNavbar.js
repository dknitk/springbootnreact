import React, { useState } from "react";
import { Collapse, NavItem, NavLink, NavbarBrand, NavbarToggler, Navbar } from "reactstrap";
import { Link } from 'react-router-dom';

const AppNavbar = () =>{

    const [isOpen, setIsOpen] = useState(false);
    return (
        <Navbar color="dark" dark expand="md">
            <NavbarBrand tag={Link} to="/">Home</NavbarBrand>
            <NavbarBrand onClick={() => {setIsOpen(!isOpen) }}></NavbarBrand>
            <Collapse isOpen={isOpen} navbar>
                <NavItem>
                    <NavLink href="http://twitter.com/oktadev">@ojtadev</NavLink>
                </NavItem>
                <NavItem>
                    <NavLink href="https://github.com/oktadev/okta-spring-boot-react-cloud-example">GitHub</NavLink>
                </NavItem>
            
            </Collapse>
        </Navbar>
    );
}

export default AppNavbar;