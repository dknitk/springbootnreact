package com.kw.developer.jugtours.web;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
//import org.springframework.security.oauth2.client.registration.ClientRegistration;

@RestController
public class UserController {

    //private final ClientRegistration registration;

    @PostMapping("/api/logout")
    public ResponseEntity<?> logout(HttpServletRequest request){
        StringBuilder logoutUrl = new StringBuilder();
        //String issueUri = this.regis
        return null;
    }
}
